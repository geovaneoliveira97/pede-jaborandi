// src/components/ProductCard.tsx
//
// Card de produto inspirado no iFood:
// • Imagem opcional à direita (URL) com fallback para emoji
// • Nome, descrição e preço à esquerda
// • Botão + tonal

import type { Product } from '../types/types'

interface ProductCardProps {
  product:     Product
  categoryEmoji: string   // emoji da categoria da loja (fallback de imagem)
  onAdd:       (product: Product) => void
}

function formatPrice(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value)
}

export default function ProductCard({ product, categoryEmoji, onAdd }: ProductCardProps) {
  return (
    <div
      className="flex gap-3 p-4 transition-all duration-150"
      style={{
        borderRadius: 'var(--shape-lg)',
        border:       '1px solid var(--md-outline-variant)',
        background:   'var(--md-surface-lowest)',
      }}
    >
      {/* Texto */}
      <div className="flex-1 min-w-0 flex flex-col justify-between">
        <div>
          <p
            className="font-bold text-sm leading-snug"
            style={{ color: 'var(--md-on-surface)' }}
          >
            {product.name}
          </p>
          {product.description && (
            <p
              className="text-xs mt-1 leading-relaxed line-clamp-2"
              style={{ color: 'var(--md-on-surface-variant)' }}
            >
              {product.description}
            </p>
          )}
        </div>

        <div className="flex items-center justify-between mt-3">
          <p className="text-sm font-black" style={{ color: 'var(--md-primary)' }}>
            <span className="text-xs font-semibold" style={{ color: 'var(--md-on-surface-variant)' }}>R$ </span>
            {formatPrice(product.price)}
          </p>

          <button
            onClick={() => onAdd(product)}
            aria-label={`Adicionar ${product.name} ao carrinho`}
            className="ripple w-9 h-9 flex items-center justify-center text-xl font-bold transition-all active:scale-90"
            style={{
              borderRadius: 'var(--shape-md)',
              background:   'var(--md-primary-container)',
              color:        'var(--md-on-primary-container)',
              border:       'none',
              flexShrink:   0,
            }}
          >
            +
          </button>
        </div>
      </div>

      {/* Imagem — direita, como no iFood */}
      <div
        className="flex-shrink-0 flex items-center justify-center overflow-hidden"
        style={{
          width:        '88px',
          height:       '88px',
          borderRadius: 'var(--shape-md)',
          background:   'linear-gradient(135deg, var(--md-primary-container), var(--md-tertiary-container))',
        }}
      >
        {product.image ? (
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <span className="text-4xl" aria-hidden="true">{categoryEmoji}</span>
        )}
      </div>
    </div>
  )
}

// src/components/StoreCard.tsx
// Card compacto com badge de vitrine para mercados sem entrega

import type { Store } from '../types/types'
import { DEFAULT_STORE_COLOR } from '../types/types'

interface StoreCardProps {
  store:    Store
  onSelect: (store: Store) => void
}

export default function StoreCard({ store, onSelect }: StoreCardProps) {
  const isClosed  = store.status === 'closed'
  const isVitrine = store.mode === 'vitrine'
  const color     = store.color || DEFAULT_STORE_COLOR
  const emoji     = store.category.split(' ')[0]
  const rating    = typeof store.rating === 'number' ? store.rating : null

  return (
    <button
      onClick={() => !isClosed && onSelect(store)}
      disabled={isClosed}
      aria-label={
        isClosed    ? `${store.name} — fechado` :
        isVitrine   ? `Ver preços de ${store.name}` :
                      `Ver cardápio de ${store.name}`
      }
      className={`w-full text-left overflow-hidden transition-all duration-200 active:scale-[0.98] ${
        isClosed ? 'opacity-60 cursor-not-allowed' : ''
      }`}
      style={{
        borderRadius: '14px',
        border:       isVitrine ? '1px solid #BFDBFE' : '1px solid #e5e7eb',
        background:   '#ffffff',
        boxShadow:    isClosed ? 'none' : '0 1px 3px rgba(0,0,0,0.08)',
      }}
    >
      {/* Banner */}
      <div className="relative" style={{ height: '80px' }}>
        {store.coverImage ? (
          <img src={store.coverImage} alt={store.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center"
            style={{ backgroundColor: isVitrine ? '#DBEAFE' : color }} aria-hidden="true">
            <span style={{ fontSize: '32px' }} className="filter drop-shadow-md">{emoji}</span>
          </div>
        )}
        <div className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.4) 0%, transparent 55%)' }}
          aria-hidden="true" />

        {/* Status */}
        <span className="absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-full"
          style={isClosed
            ? { background: 'rgba(0,0,0,0.5)', color: '#fff' }
            : isVitrine
              ? { background: '#1d4ed8', color: '#fff' }
              : { background: '#16A34A', color: '#fff' }
          }>
          {isClosed ? '● Fechado' : isVitrine ? '🏪 Ver preços' : '● Aberto'}
        </span>

        {/* Rating */}
        {rating !== null && (
          <span className="absolute top-2 right-2 text-[10px] font-bold px-2 py-0.5 rounded-full"
            style={{ background: 'rgba(0,0,0,0.5)', color: '#fff' }}>
            ★ {rating.toFixed(1)}
          </span>
        )}

        {/* Categoria */}
        <span className="absolute bottom-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-full"
          style={{ background: 'rgba(0,0,0,0.35)', color: '#fff' }}>
          {store.category}
        </span>
      </div>

      {/* Body */}
      <div style={{ padding: '8px 12px' }}>
        <p className="font-bold text-sm truncate" style={{ color: '#111827' }}>{store.name}</p>
        {store.description && (
          <p className="text-xs mt-0.5 truncate" style={{ color: '#9ca3af' }}>{store.description}</p>
        )}
        <div className="flex items-center gap-2 flex-wrap" style={{ marginTop: '5px' }}>
          {isVitrine ? (
            <span className="text-xs font-semibold" style={{ color: '#1d4ed8' }}>
              📋 {store.products.length} produtos cadastrados
            </span>
          ) : (
            <>
              {store.deliveryTime && (
                <span className="text-xs font-semibold" style={{ color: '#9ca3af' }}>🕐 {store.deliveryTime}</span>
              )}
              {store.deliveryTime && <span className="w-1 h-1 rounded-full" style={{ background: '#d1d5db' }} aria-hidden="true" />}
              <span className="text-xs font-semibold" style={{ color: '#16A34A' }}>🛵 Entrega grátis</span>
              <span className="w-1 h-1 rounded-full" style={{ background: '#d1d5db' }} aria-hidden="true" />
              <span className="text-xs font-semibold" style={{ color: '#9ca3af' }}>
                {store.products.length} {store.products.length === 1 ? 'item' : 'itens'}
              </span>
            </>
          )}
        </div>
      </div>
    </button>
  )
}

// src/components/LoadingScreen.tsx
//
// Material You — Telas de estado
// Spinner usa a cor primária M3; ErrorScreen usa error-container M3.

interface ErrorScreenProps {
  onRetry: () => void
}

export function LoadingScreen() {
  return (
    <div
      role="status"
      aria-live="polite"
      aria-label="Carregando comércios"
      className="min-h-screen flex flex-col items-center justify-center gap-4"
      style={{ background: 'var(--md-background)' }}
    >
      <div
        className="w-10 h-10 border-4 border-t-transparent rounded-full animate-spin"
        style={{ borderColor: 'var(--md-primary-container)', borderTopColor: 'transparent' }}
        aria-hidden="true"
      />
      <p className="text-sm font-medium" style={{ color: 'var(--md-on-surface-variant)' }}>
        Carregando comércios...
      </p>
    </div>
  )
}

export function ErrorScreen({ onRetry }: ErrorScreenProps) {
  return (
    <div
      role="alert"
      className="min-h-screen flex flex-col items-center justify-center gap-4 px-8 text-center"
      style={{ background: 'var(--md-background)' }}
    >
      <div
        className="w-16 h-16 flex items-center justify-center"
        style={{ borderRadius: 'var(--shape-xl)', background: 'var(--md-error-container)' }}
      >
        <svg
          viewBox="0 0 24 24"
          fill="none"
          stroke="var(--md-on-error-container)"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="w-8 h-8"
          aria-hidden="true"
        >
          <circle cx="12" cy="12" r="9" />
          <line x1="12" y1="8" x2="12" y2="12" />
          <line x1="12" y1="16" x2="12.01" y2="16" />
        </svg>
      </div>

      <div>
        <p className="font-bold" style={{ color: 'var(--md-on-surface)', fontFamily: 'Google Sans Display, sans-serif', fontSize: '18px' }}>
          Sem conexão
        </p>
        <p className="text-sm mt-1" style={{ color: 'var(--md-on-surface-variant)' }}>
          Não foi possível carregar os comércios.
          Verifique sua internet e tente novamente.
        </p>
      </div>

      <button
        onClick={onRetry}
        className="btn-primary mt-2"
      >
        Tentar novamente
      </button>
    </div>
  )
}

// src/components/PizzaModal.tsx
//
// Modal de configuração de pizza em 3 etapas:
//   1. Tamanho (Grande / Broto)
//   2. Sabores (inteiro ou metade/metade)
//   3. Borda
//
// Design segue o sistema Material You já estabelecido no projeto.

import { useState, useMemo } from 'react'
import type { Product, PizzaSize, PizzaCrust } from '../types/types'
import { formatBRL } from '../lib/format'

interface PizzaConfig {
  size:    PizzaSize
  half:    Product | null    // segundo sabor (metade/metade) ou null
  crust:   PizzaCrust
}

interface PizzaModalProps {
  product:      Product            // pizza principal (1º sabor)
  allPizzas:    Product[]          // lista de todas as pizzas para escolha de metade
  storeColor:   string
  onConfirm:    (config: PizzaConfig, finalPrice: number) => void
  onClose:      () => void
}

type Step = 'size' | 'flavor' | 'crust'
const STEPS: Step[] = ['size', 'flavor', 'crust']
const STEP_LABELS: Record<Step, string> = {
  size:   'Tamanho',
  flavor: 'Sabores',
  crust:  'Borda',
}

export default function PizzaModal({ product, allPizzas, storeColor, onConfirm, onClose }: PizzaModalProps) {
  const sizes  = product.sizes  ?? []
  const crusts = product.crusts ?? []
  const allowHalf = product.allowHalf !== false

  const [step,       setStep]       = useState<Step>('size')
  const [size,       setSize]       = useState<PizzaSize | null>(sizes[0] ?? null)
  const [wantHalf,   setWantHalf]   = useState(false)
  const [halfFlavor, setHalfFlavor] = useState<Product | null>(null)
  const [crust,      setCrust]      = useState<PizzaCrust | null>(crusts[0] ?? null)

  const stepIndex = STEPS.indexOf(step)

  // Preço calculado em tempo real
  const finalPrice = useMemo(() => {
  if (!size) return 0

  let basePrice = size.price

  if (wantHalf && halfFlavor) {
    // Busca o preço do mesmo tamanho no 2º sabor
    const halfSize = halfFlavor.sizes?.find(s => s.id === size.id)
    const halfPrice = halfSize?.price ?? halfFlavor.price
    // Cobra o maior dos dois (padrão do mercado)
    basePrice = Math.max(size.price, halfPrice)
  }

  return basePrice + (crust?.extra ?? 0)
}, [size, crust, wantHalf, halfFlavor])
  

  function advance() {
    if (step === 'size')   setStep('flavor')
    if (step === 'flavor') setStep('crust')
    if (step === 'crust')  handleConfirm()
  }

  function canAdvance() {
    if (step === 'size')   return size !== null
    if (step === 'flavor') return !wantHalf || halfFlavor !== null
    if (step === 'crust')  return crust !== null
    return false
  }

  function handleConfirm() {
    if (!size || !crust) return
    onConfirm({ size, half: wantHalf ? halfFlavor : null, crust }, finalPrice)
  }

  const otherPizzas = allPizzas.filter(p => p.id !== product.id && p.productType === 'pizza')

  return (
    <div
      role="dialog" aria-modal="true" aria-label={`Configurar ${product.name}`}
      style={{
        position: 'fixed', inset: 0, zIndex: 60,
        display: 'flex', alignItems: 'flex-end', justifyContent: 'center',
        background: 'rgba(0,0,0,0.5)',
      }}
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div
        style={{
          width: '100%', maxWidth: '480px',
          background: 'var(--md-surface-lowest)',
          borderRadius: 'var(--shape-xl) var(--shape-xl) 0 0',
          boxShadow: 'var(--md-elev-3)',
          overflow: 'hidden',
          maxHeight: '92dvh',
          display: 'flex', flexDirection: 'column',
        }}
      >
        {/* Drag handle */}
        <div style={{ display: 'flex', justifyContent: 'center', paddingTop: '12px' }}>
          <div style={{ width: '36px', height: '4px', borderRadius: '2px', background: 'var(--md-outline-variant)' }} />
        </div>

        {/* Header */}
        <div style={{ padding: '12px 20px 0' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: '8px' }}>
            <div>
              <p style={{ fontFamily: 'Google Sans Display, sans-serif', fontWeight: 700, fontSize: '16px', color: 'var(--md-on-surface)', margin: 0 }}>
                {product.name}
              </p>
              {product.description && (
                <p style={{ fontSize: '12px', color: 'var(--md-on-surface-variant)', marginTop: '2px', marginBottom: 0 }}>
                  {product.description}
                </p>
              )}
            </div>
            <button
              onClick={onClose}
              aria-label="Fechar"
              style={{ background: 'none', border: 'none', padding: '4px', cursor: 'pointer', color: 'var(--md-on-surface-variant)', fontSize: '20px', lineHeight: 1, flexShrink: 0 }}
            >
              ✕
            </button>
          </div>

          {/* Stepper */}
          <div style={{ display: 'flex', gap: '6px', marginTop: '16px', marginBottom: '4px' }}>
            {STEPS.map((s, i) => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: '6px', flex: 1 }}>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: '6px',
                  opacity: i > stepIndex ? 0.4 : 1,
                  transition: 'opacity 0.2s',
                }}>
                  <div style={{
                    width: '22px', height: '22px', borderRadius: '50%',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: '11px', fontWeight: 700, flexShrink: 0,
                    background: i <= stepIndex ? storeColor : 'var(--md-surface-container, var(--md-surface-highest))',
                    color: i <= stepIndex ? '#fff' : 'var(--md-on-surface-variant)',
                    transition: 'background 0.2s',
                  }}>
                    {i < stepIndex ? '✓' : i + 1}
                  </div>
                  <span style={{ fontSize: '11px', fontWeight: 600, color: i === stepIndex ? 'var(--md-on-surface)' : 'var(--md-on-surface-variant)', whiteSpace: 'nowrap' }}>
                    {STEP_LABELS[s]}
                  </span>
                </div>
                {i < STEPS.length - 1 && (
                  <div style={{ flex: 1, height: '1px', background: 'var(--md-outline-variant)', minWidth: '8px' }} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Content — scrollable */}
        <div style={{ flex: 1, overflowY: 'auto', padding: '16px 20px' }}>

          {/* ── Etapa 1: Tamanho ── */}
          {step === 'size' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {sizes.length === 0 && (
                <p style={{ color: 'var(--md-on-surface-variant)', fontSize: '13px', textAlign: 'center' }}>
                  Nenhum tamanho cadastrado para esta pizza.
                </p>
              )}
              {sizes.map(s => (
                <button
                  key={s.id}
                  onClick={() => setSize(s)}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '14px 16px', borderRadius: 'var(--shape-lg)',
                    border: `2px solid ${size?.id === s.id ? storeColor : 'var(--md-outline-variant)'}`,
                    background: size?.id === s.id ? `${storeColor}14` : 'var(--md-surface-lowest)',
                    cursor: 'pointer', transition: 'border-color 0.15s, background 0.15s',
                    textAlign: 'left', width: '100%',
                  }}
                >
                  <div>
                    <p style={{ margin: 0, fontWeight: 700, fontSize: '14px', color: 'var(--md-on-surface)' }}>{s.label}</p>
                    <p style={{ margin: '2px 0 0', fontSize: '12px', color: 'var(--md-on-surface-variant)' }}>{s.info}</p>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <span style={{ fontWeight: 800, fontSize: '15px', color: storeColor }}>{formatBRL(s.price)}</span>
                    <div style={{
                      width: '20px', height: '20px', borderRadius: '50%', flexShrink: 0,
                      border: `2px solid ${size?.id === s.id ? storeColor : 'var(--md-outline-variant)'}`,
                      background: size?.id === s.id ? storeColor : 'none',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {size?.id === s.id && <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#fff' }} />}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}

          {/* ── Etapa 2: Sabores ── */}
          {step === 'flavor' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
              {/* 1º sabor (fixo) */}
              <div style={{
                padding: '12px 16px', borderRadius: 'var(--shape-lg)',
                border: `2px solid ${storeColor}`,
                background: `${storeColor}14`,
              }}>
                <p style={{ margin: 0, fontSize: '11px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: storeColor }}>1º Sabor</p>
                <p style={{ margin: '4px 0 0', fontWeight: 700, fontSize: '14px', color: 'var(--md-on-surface)' }}>{product.name}</p>
              </div>

              {/* Toggle metade/metade */}
              {allowHalf && otherPizzas.length > 0 && (
                <button
                  onClick={() => { setWantHalf(w => !w); if (wantHalf) setHalfFlavor(null) }}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '12px 16px', borderRadius: 'var(--shape-lg)',
                    border: `1px solid var(--md-outline-variant)`,
                    background: 'var(--md-surface-lowest)',
                    cursor: 'pointer', width: '100%', textAlign: 'left',
                  }}
                >
                  <div>
                    <p style={{ margin: 0, fontWeight: 700, fontSize: '13px', color: 'var(--md-on-surface)' }}>Metade/metade</p>
                    <p style={{ margin: '2px 0 0', fontSize: '12px', color: 'var(--md-on-surface-variant)' }}>Escolher um segundo sabor</p>
                  </div>
                  {/* Toggle switch */}
                  <div style={{
                    width: '44px', height: '24px', borderRadius: '12px', position: 'relative', flexShrink: 0,
                    background: wantHalf ? storeColor : 'var(--md-outline-variant)',
                    transition: 'background 0.2s',
                  }}>
                    <div style={{
                      position: 'absolute', top: '3px',
                      left: wantHalf ? '23px' : '3px',
                      width: '18px', height: '18px', borderRadius: '50%',
                      background: '#fff', transition: 'left 0.2s',
                    }} />
                  </div>
                </button>
              )}

              {/* Grade de seleção do 2º sabor */}
              {wantHalf && (
                <div>
                  <p style={{ margin: '0 0 8px', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.05em', color: 'var(--md-on-surface-variant)' }}>
                    2º Sabor
                  </p>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', maxHeight: '240px', overflowY: 'auto' }}>
                    {otherPizzas.map(p => (
                      <button
                        key={p.id}
                        onClick={() => setHalfFlavor(p)}
                        style={{
                          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                          padding: '10px 14px', borderRadius: 'var(--shape-md)',
                          border: `2px solid ${halfFlavor?.id === p.id ? storeColor : 'var(--md-outline-variant)'}`,
                          background: halfFlavor?.id === p.id ? `${storeColor}14` : 'var(--md-surface-lowest)',
                          cursor: 'pointer', width: '100%', textAlign: 'left',
                          transition: 'border-color 0.15s, background 0.15s',
                        }}
                      >
                        <p style={{ margin: 0, fontWeight: 600, fontSize: '13px', color: 'var(--md-on-surface)' }}>{p.name}</p>
                        <div style={{
                          width: '18px', height: '18px', borderRadius: '50%', flexShrink: 0,
                          border: `2px solid ${halfFlavor?.id === p.id ? storeColor : 'var(--md-outline-variant)'}`,
                          background: halfFlavor?.id === p.id ? storeColor : 'none',
                          display: 'flex', alignItems: 'center', justifyContent: 'center',
                        }}>
                          {halfFlavor?.id === p.id && <div style={{ width: '6px', height: '6px', borderRadius: '50%', background: '#fff' }} />}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── Etapa 3: Borda ── */}
          {step === 'crust' && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {crusts.length === 0 && (
                <p style={{ color: 'var(--md-on-surface-variant)', fontSize: '13px', textAlign: 'center' }}>
                  Nenhuma opção de borda cadastrada.
                </p>
              )}
              {crusts.map(c => (
                <button
                  key={c.id}
                  onClick={() => setCrust(c)}
                  style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                    padding: '14px 16px', borderRadius: 'var(--shape-lg)',
                    border: `2px solid ${crust?.id === c.id ? storeColor : 'var(--md-outline-variant)'}`,
                    background: crust?.id === c.id ? `${storeColor}14` : 'var(--md-surface-lowest)',
                    cursor: 'pointer', width: '100%', textAlign: 'left',
                    transition: 'border-color 0.15s, background 0.15s',
                  }}
                >
                  <p style={{ margin: 0, fontWeight: 700, fontSize: '14px', color: 'var(--md-on-surface)' }}>{c.label}</p>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    {c.extra > 0 && (
                      <span style={{ fontSize: '12px', color: 'var(--md-on-surface-variant)' }}>+ {formatBRL(c.extra)}</span>
                    )}
                    {c.extra === 0 && (
                      <span style={{ fontSize: '12px', color: 'var(--md-on-surface-variant)' }}>Grátis</span>
                    )}
                    <div style={{
                      width: '20px', height: '20px', borderRadius: '50%', flexShrink: 0,
                      border: `2px solid ${crust?.id === c.id ? storeColor : 'var(--md-outline-variant)'}`,
                      background: crust?.id === c.id ? storeColor : 'none',
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                    }}>
                      {crust?.id === c.id && <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#fff' }} />}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div style={{ padding: '12px 20px 24px', borderTop: '1px solid var(--md-outline-variant)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '12px' }}>
            <div>
              <p style={{ margin: 0, fontSize: '11px', color: 'var(--md-on-surface-variant)' }}>Total</p>
              <p style={{ margin: 0, fontWeight: 800, fontSize: '20px', color: storeColor }}>{formatBRL(finalPrice)}</p>
            </div>
            {step !== 'size' && (
              <button
                onClick={() => setStep(STEPS[stepIndex - 1])}
                style={{
                  padding: '10px 16px', borderRadius: 'var(--shape-full)',
                  border: '1px solid var(--md-outline-variant)',
                  background: 'none', cursor: 'pointer', fontSize: '13px', fontWeight: 700,
                  color: 'var(--md-on-surface-variant)',
                }}
              >
                ← Voltar
              </button>
            )}
          </div>
          <button
            onClick={advance}
            disabled={!canAdvance()}
            style={{
              width: '100%', padding: '14px', borderRadius: 'var(--shape-full)',
              border: 'none', cursor: canAdvance() ? 'pointer' : 'not-allowed',
              background: canAdvance() ? storeColor : 'var(--md-outline-variant)',
              color: '#fff', fontWeight: 800, fontSize: '15px',
              transition: 'background 0.2s',
            }}
          >
            {step === 'crust' ? '🛒 Adicionar ao carrinho' : `Próximo →`}
          </button>
        </div>
      </div>
    </div>
  )
}

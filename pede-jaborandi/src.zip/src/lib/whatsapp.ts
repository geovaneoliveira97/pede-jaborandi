// src/lib/whatsapp.ts
import type { CartItem, CustomerData, Store, OrderStatus } from '../types/types'
import { PAYMENT_LABELS, ORDER_STATUS_LABELS } from '../types/types'
import { formatBRL } from './format'

function buildFullAddress(c: CustomerData): string {
  return [
    c.street,
    c.number      ? `nº ${c.number}`    : '',
    c.complement  ? `(${c.complement})` : '',
    c.neighborhood,
    c.city,
    c.cep         ? `CEP ${c.cep}`      : '',
  ].filter(Boolean).join(', ')
}

/** Formata uma linha de item do carrinho, incluindo configuração de pizza */
function formatItem(i: CartItem): string {
  const lines: string[] = [`▪️ ${i.qty}x ${i.name}`]

  // Detalhes da pizza, se houver
  if (i.size || i.half || i.crust) {
    const details: string[] = []
    if (i.size)  details.push(`📏 ${i.size}`)
    if (i.half)  details.push(`½ + ½ ${i.half}`)
    if (i.crust) details.push(`Borda: ${i.crust}`)
    lines.push(`   ${details.join(' · ')}`)
  }

  lines.push(`   ${formatBRL(i.price * i.qty)}`)
  return lines.join('\n')
}

export function buildOrderMessage(
  _store:   Store,
  items:    CartItem[],
  customer: CustomerData,
): string {
  const total       = items.reduce((sum, i) => sum + i.price * i.qty, 0)
  const itemsText   = items.map(formatItem).join('\n')
  const fullAddress = buildFullAddress(customer)
  const referenceText = customer.reference.trim()
    ? `\n📌 *Referência:* ${customer.reference.trim()}`
    : ''

  return [
    `🛵 *NOVO PEDIDO — Pede Jaborandi*`,
    ``,
    `👤 *Cliente:* ${customer.name}`,
    `📱 *Telefone:* ${customer.phone}`,
    `📍 *Endereço:* ${fullAddress}${referenceText}`,
    ``,
    `🛒 *Itens do Pedido:*`,
    itemsText,
    ``,
    `💰 *Total: ${formatBRL(total)}*`,
    `💳 *Pagamento:* ${PAYMENT_LABELS[customer.payment]}`,
    ``,
    `_Pedido feito pelo app Pede Jaborandi_ 🛵`,
  ].join('\n')
}

// ── Status do pedido — mensagem enviada para o cliente ──────────────────────

export function buildStatusMessage(
  storeName:    string,
  orderId:      string,
  status:       OrderStatus,
  customerName: string,
): string {
  const label = ORDER_STATUS_LABELS[status]
  const msgs: Record<OrderStatus, string> = {
    recebido:   `Olá *${customerName}*! Seu pedido foi *recebido* por ${storeName} e já está na fila. 📋`,
    preparando: `Olá *${customerName}*! ${storeName} está *preparando* seu pedido agora. 👨‍🍳`,
    saiu:       `Olá *${customerName}*! Seu pedido *saiu para entrega*! Aguarde em breve. 🛵`,
    entregue:   `Olá *${customerName}*! Seu pedido foi *entregue*. Bom apetite! ✅\n\nObrigado por usar o Pede Jaborandi! 🧡`,
  }
  return [
    `${label}`,
    ``,
    msgs[status],
    ``,
    `_Pedido #${orderId.slice(-6).toUpperCase()} · Pede Jaborandi_`,
  ].join('\n')
}

export function openWhatsApp(phone: string, message: string): void {
  const encoded = encodeURIComponent(message)
  window.open(`https://wa.me/${phone}?text=${encoded}`, '_blank', 'noopener,noreferrer')
}

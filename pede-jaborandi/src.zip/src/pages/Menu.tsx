// src/pages/Menu.tsx
//
// Cardápio com suporte a pizzas configuráveis:
// • Produtos do tipo 'pizza' abrem o PizzaModal (tamanho → sabores → borda)
// • Produtos simples (bebidas, etc.) continuam adicionando diretamente
// • Modal de troca de loja mantido

import { useMemo, useCallback, useState } from 'react'
import type { Store, Product } from '../types/types'
import type { UseCartResult } from '../hooks/useCart'
import ProductCard from '../components/ProductCard'
import PizzaModal from '../components/PizzaModal'
import { DEFAULT_STORE_COLOR } from '../types/types'

type AddItemFn = UseCartResult['addItem']

interface MenuProps {
  store:     Store
  addItem:   AddItemFn
  clearCart: () => void
  showToast: (msg: string) => void
}

// ── Modal troca de loja ────────────────────────────────────────────────────

interface SwitchStoreModalProps {
  fromStore: string
  toStore:   string
  onConfirm: () => void
  onCancel:  () => void
}

function SwitchStoreModal({ fromStore, toStore, onConfirm, onCancel }: SwitchStoreModalProps) {
  return (
    <div
      role="dialog" aria-modal="true" aria-label="Trocar comércio"
      className="fixed inset-0 z-50 flex items-center justify-center px-6"
      style={{ background: 'rgba(0,0,0,0.45)' }}
    >
      <div
        className="w-full max-w-sm p-6 space-y-4"
        style={{ background: 'var(--md-surface-lowest)', borderRadius: 'var(--shape-xl)', boxShadow: 'var(--md-elev-3)' }}
      >
        <div className="text-center space-y-1">
          <span className="text-3xl">🔄</span>
          <p className="font-bold text-lg" style={{ color: 'var(--md-on-surface)', fontFamily: 'Google Sans Display, sans-serif' }}>
            Trocar comércio?
          </p>
          <p className="text-sm" style={{ color: 'var(--md-on-surface-variant)' }}>
            Você tem itens de <strong>{fromStore}</strong> no carrinho.
            Para adicionar de <strong>{toStore}</strong>, o carrinho será esvaziado.
          </p>
        </div>
        <div className="flex gap-3">
          <button
            onClick={onCancel}
            className="flex-1 py-2.5 text-sm font-bold rounded-full transition-all active:scale-95"
            style={{ border: '1px solid var(--md-outline-variant)', color: 'var(--md-on-surface-variant)', background: 'none' }}
          >
            Manter carrinho
          </button>
          <button
            onClick={onConfirm}
            className="flex-1 py-2.5 text-sm font-bold rounded-full transition-all active:scale-95"
            style={{ background: 'var(--md-primary)', color: 'var(--md-on-primary)', border: 'none' }}
          >
            Trocar loja
          </button>
        </div>
      </div>
    </div>
  )
}

function groupBySection(products: Product[]): Map<string, Product[]> {
  return products.reduce((map, p) => {
    const group = map.get(p.section) ?? []
    group.push(p)
    return map.set(p.section, group)
  }, new Map<string, Product[]>())
}

export default function Menu({ store, addItem, clearCart, showToast }: MenuProps) {
  const color         = store.color || DEFAULT_STORE_COLOR
  const categoryEmoji = store.category.split(' ')[0]
  const groups        = useMemo(() => groupBySection(store.products), [store.products])
  const rating        = typeof store.rating === 'number' ? store.rating : null

  // Modal de troca de loja
  const [pendingProduct,   setPendingProduct]   = useState<Product | null>(null)
  const [currentStoreName, setCurrentStoreName] = useState('')

  // Modal de configuração de pizza
  const [pizzaProduct, setPizzaProduct] = useState<Product | null>(null)

  const isPizza = (product: Product) =>
    product.productType === 'pizza' && Array.isArray(product.sizes) && product.sizes.length > 0

  /** Tenta adicionar um produto simples (sem configuração) */
  const addSimple = useCallback((product: Product) => {
    const result = addItem(store, product)
    if (result === 'different_store') {
      setPendingProduct(product)
      try {
        const raw = localStorage.getItem('pj_cart')
        if (raw) {
          const its = JSON.parse(raw) as Array<{ storeId: number }>
          const storedId = its[0]?.storeId
          if (storedId) setCurrentStoreName(`loja #${storedId}`)
        }
      } catch { setCurrentStoreName('outro comércio') }
      return
    }
    showToast(`✓ ${product.name} adicionado!`)
  }, [store, addItem, showToast])

  const handleAdd = useCallback((product: Product) => {
    if (isPizza(product)) {
      setPizzaProduct(product)
    } else {
      addSimple(product)
    }
  }, [addSimple])

  const confirmSwitch = useCallback(() => {
    if (!pendingProduct) return
    clearCart()
    if (isPizza(pendingProduct)) {
      setPizzaProduct(pendingProduct)
    } else {
      addItem(store, pendingProduct)
      showToast(`✓ ${pendingProduct.name} adicionado!`)
    }
    setPendingProduct(null)
  }, [pendingProduct, store, addItem, clearCart, showToast])

  // Lista de todas as pizzas da loja (para metade/metade)
  const allPizzas = useMemo(
    () => store.products.filter(p => p.productType === 'pizza'),
    [store.products],
  )

  return (
    <div className="animate-enter">

      {/* Modal troca de loja */}
      {pendingProduct && (
        <SwitchStoreModal
          fromStore={currentStoreName}
          toStore={store.name}
          onConfirm={confirmSwitch}
          onCancel={() => setPendingProduct(null)}
        />
      )}

      {/* Modal de configuração de pizza */}
      {pizzaProduct && (
        <PizzaModal
          product={pizzaProduct}
          allPizzas={allPizzas}
          storeColor={color}
          onConfirm={(config, finalPrice) => {
            const result = addItem(store, pizzaProduct, {
              size:       config.size.label,
              crust:      config.crust.label,
              half:       config.half?.name,
              finalPrice,
            })
            if (result === 'different_store') {
              // Usuário já estava no modal, não precisamos de swap aqui
              // (caso raro — manter o toast)
              showToast('Esvazie o carrinho para adicionar de outra loja.')
            } else {
              const halfText = config.half ? ` (½ ${config.half.name})` : ''
              showToast(`✓ ${pizzaProduct.name}${halfText} adicionado!`)
            }
            setPizzaProduct(null)
          }}
          onClose={() => setPizzaProduct(null)}
        />
      )}

      {/* ── Banner do comércio ── */}
      <div
        className="relative flex items-end"
        style={{
          height:          '200px',
          borderRadius:    '0 0 var(--shape-xl) var(--shape-xl)',
          overflow:        'hidden',
          backgroundColor: color,
        }}
        aria-hidden="true"
      >
        {store.coverImage ? (
          <img src={store.coverImage} alt="" className="absolute inset-0 w-full h-full object-cover" />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="text-9xl filter drop-shadow-lg">{categoryEmoji}</span>
          </div>
        )}
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(to top, rgba(0,0,0,0.65) 0%, transparent 55%)' }}
        />
        <div className="relative w-full px-5 pb-5">
          <p
            className="text-white font-bold text-xl leading-snug drop-shadow"
            style={{ fontFamily: 'Google Sans Display, sans-serif' }}
          >
            {store.name}
          </p>
          <div className="flex items-center gap-3 mt-1 flex-wrap">
            {rating !== null && (
              <span className="text-[12px] font-bold text-white opacity-90">★ {rating.toFixed(1)}</span>
            )}
            {store.deliveryTime && (
              <>
                <span className="text-white opacity-50 text-xs">·</span>
                <span className="text-[12px] text-white opacity-90">🕐 {store.deliveryTime}</span>
              </>
            )}
            <span className="text-white opacity-50 text-xs">·</span>
            <span className="text-[12px] text-white opacity-90">🛵 Entrega grátis</span>
          </div>
        </div>
      </div>

      {/* ── Cardápio ── */}
      {store.status === 'closed' ? (
        <div className="flex flex-col items-center justify-center py-20 gap-3 text-center px-8">
          <span className="text-5xl">😴</span>
          <p className="font-bold text-lg" style={{ color: 'var(--md-on-surface)', fontFamily: 'Google Sans Display, sans-serif' }}>
            Fechado no momento
          </p>
          <p className="text-sm" style={{ color: 'var(--md-on-surface-variant)' }}>
            Este comércio está fechado. Tente novamente mais tarde.
          </p>
        </div>
      ) : (
        <div className="px-4 py-5 space-y-6">
          {[...groups.entries()].map(([section, products]) => (
            <section key={section} aria-label={section}>
              <h2
                className="text-sm font-bold uppercase tracking-widest mb-3"
                style={{ color: 'var(--md-on-surface-variant)' }}
              >
                {section}
              </h2>
              <div className="space-y-3">
                {products.map(product => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    categoryEmoji={categoryEmoji}
                    onAdd={handleAdd}
                  />
                ))}
              </div>
            </section>
          ))}

          {store.products.length === 0 && (
            <p className="text-center text-sm py-12" style={{ color: 'var(--md-on-surface-variant)' }}>
              Nenhum produto cadastrado neste comércio.
            </p>
          )}
        </div>
      )}
    </div>
  )
}

// src/data/mockStores.ts
//
// Dados mockados com suporte a pizzas configuráveis.
// A Pizzaria Bella Napoli agora tem sizes, crusts e allowHalf.

import type { Store } from '../types/types'

export const MOCK_STORES: Store[] = [
  {
    id:           1,
    name:         'Pizzaria Bella Napoli',
    category:     '🍕 Pizzaria',
    description:  'Pizzas artesanais no forno a lenha',
    phone:        '5519999110001',
    color:        '#C0392B',
    status:       'open',
    mode:         'delivery',
    rating:       4.9,
    deliveryTime: '30–45 min',
    products: [
      {
        id: 1, productType: 'pizza', section: 'Pizzas',
        name: 'Pizza Marguerita',
        description: 'Molho, mozzarella e manjericão fresco',
        price: 38,  // menor tamanho como referência
        allowHalf: true,
        sizes: [
          { id: 'grande', label: 'Grande 35cm', info: '8 pedaços',  price: 55 },
          { id: 'broto',  label: 'Broto',       info: '4 pedaços',  price: 38 },
        ],
        crusts: [
          { id: 'sem_borda',  label: 'Sem borda',          extra: 0  },
          { id: 'catupiry',   label: 'Catupiry',            extra: 6  },
          { id: 'cheddar',    label: 'Cheddar',             extra: 6  },
          { id: 'chocolate',  label: 'Chocolate (doce)',    extra: 8  },
        ],
      },
      {
        id: 2, productType: 'pizza', section: 'Pizzas',
        name: 'Pizza Calabresa',
        description: 'Calabresa artesanal, cebola e azeitona',
        price: 42,
        allowHalf: true,
        sizes: [
          { id: 'grande', label: 'Grande 35cm', info: '8 pedaços',  price: 58 },
          { id: 'broto',  label: 'Broto',       info: '4 pedaços',  price: 42 },
        ],
        crusts: [
          { id: 'sem_borda',  label: 'Sem borda',          extra: 0  },
          { id: 'catupiry',   label: 'Catupiry',            extra: 6  },
          { id: 'cheddar',    label: 'Cheddar',             extra: 6  },
          { id: 'chocolate',  label: 'Chocolate (doce)',    extra: 8  },
        ],
      },
      {
        id: 3, productType: 'pizza', section: 'Pizzas',
        name: 'Pizza Frango c/ Catupiry',
        description: 'Frango desfiado, catupiry e milho verde',
        price: 45,
        allowHalf: true,
        sizes: [
          { id: 'grande', label: 'Grande 35cm', info: '8 pedaços',  price: 62 },
          { id: 'broto',  label: 'Broto',       info: '4 pedaços',  price: 45 },
        ],
        crusts: [
          { id: 'sem_borda',  label: 'Sem borda',          extra: 0  },
          { id: 'catupiry',   label: 'Catupiry',            extra: 6  },
          { id: 'cheddar',    label: 'Cheddar',             extra: 6  },
          { id: 'chocolate',  label: 'Chocolate (doce)',    extra: 8  },
        ],
      },
      { id: 4,  name: 'Refrigerante Lata',  description: 'Coca-Cola, Guaraná ou Fanta 350ml', price:  6, section: 'Bebidas' },
      { id: 5,  name: 'Suco Natural 500ml', description: 'Laranja, maracujá ou limão',        price:  9, section: 'Bebidas' },
    ],
  },
  {
    id:           2,
    name:         'Lanchonete do Zé',
    category:     '🍔 Lanches',
    description:  'Os melhores lanches da cidade!',
    phone:        '5519999110002',
    color:        '#E67E22',
    status:       'open',
    mode:         'delivery',
    rating:       4.7,
    deliveryTime: '20–35 min',
    products: [
      { id: 6,  name: 'X-Burguer Clássico',  description: 'Hambúrguer 120g, queijo, alface e tomate',   price: 18, section: 'Lanches'         },
      { id: 7,  name: 'X-Bacon Especial',    description: 'Hambúrguer duplo, bacon e cheddar derretido', price: 25, section: 'Lanches'         },
      { id: 8,  name: 'Cachorro-Quente',     description: 'Salsicha, molho, batata palha e creme',       price: 12, section: 'Lanches'         },
      { id: 9,  name: 'Batata Frita Média',  description: 'Porção crocante com sal',                     price: 14, section: 'Acompanhamentos' },
      { id: 10, name: 'Milk-Shake 400ml',    description: 'Chocolate, morango ou baunilha',              price: 16, section: 'Bebidas'         },
    ],
  },
  {
    id:           3,
    name:         'Açaí da Tia Cida',
    category:     '🍦 Açaí',
    description:  'Açaí fresquinho, gigante e saboroso',
    phone:        '5519999110003',
    color:        '#8E44AD',
    status:       'open',
    mode:         'delivery',
    rating:       4.8,
    deliveryTime: '15–25 min',
    products: [
      { id: 11, name: 'Açaí 300ml', description: 'Puro ou com banana e granola',          price: 14, section: 'Tigelas'   },
      { id: 12, name: 'Açaí 500ml', description: 'Tigela com frutas e granola à escolha', price: 20, section: 'Tigelas'   },
      { id: 13, name: 'Açaí 700ml', description: 'Tigela família, toppings à vontade',    price: 28, section: 'Tigelas'   },
      { id: 14, name: 'Vitamina',   description: 'Açaí batido com leite e banana',         price: 18, section: 'Vitaminas' },
    ],
  },
  {
    id:           4,
    name:         'Frango na Brasa do Léo',
    category:     '🍗 Frango',
    description:  'Frangos assados e temperados na hora',
    phone:        '5519999110004',
    color:        '#D4AC0D',
    status:       'closed',
    mode:         'delivery',
    rating:       4.6,
    deliveryTime: '35–50 min',
    products: [
      { id: 15, name: 'Frango Inteiro',       description: 'Serve 2 a 3 pessoas com arroz e farofa', price: 55, section: 'Pratos'  },
      { id: 16, name: 'Meia Frango',          description: 'Metade com acompanhamentos',              price: 32, section: 'Pratos'  },
      { id: 17, name: 'Coxinha da Asa (8un)', description: 'Porção com 8 coxinhas temperadas',        price: 24, section: 'Porções' },
    ],
  },
]
